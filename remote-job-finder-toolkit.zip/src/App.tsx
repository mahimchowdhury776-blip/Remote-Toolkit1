/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  ArrowRight, 
  FileText, 
  Briefcase, 
  MessageSquare, 
  Search, 
  Star, 
  ShieldCheck, 
  Clock, 
  ChevronDown,
  Menu,
  X,
  Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// SEO Constants
const SEO = {
  title: "Land a Remote Job in 7 Days | Free Remote Job Finder Toolkit 2026",
  description: "Get hired fast for remote jobs in USA, UK, and Canada. Free AI Resume Builder, Job Boards, and Interview Prep tools for 2026 job seekers.",
  keywords: "remote jobs USA, work from home jobs 2026, remote job tools, get hired fast online"
};

// Trust Badges Data
const TRUST_BADGES = [
  { name: "Verified USA", icon: <Globe className="w-4 h-4" /> },
  { name: "UK Approved", icon: <Globe className="w-4 h-4" /> },
  { name: "Canada Trusted", icon: <Globe className="w-4 h-4" /> },
  { name: "2026 Updated", icon: <Clock className="w-4 h-4" /> }
];

// Tools Data
const TOOLS = [
  {
    id: "resume",
    title: "AI Resume Builder",
    description: "Optimize your resume for ATS systems used by top remote companies in the US and UK.",
    icon: <FileText className="w-6 h-6 text-blue-600" />,
    cta: "Build Resume Free"
  },
  {
    id: "boards",
    title: "Remote Job Board List",
    description: "Access a curated list of 50+ high-paying remote job boards updated daily for 2026.",
    icon: <Search className="w-6 h-6 text-purple-600" />,
    cta: "View Job Boards"
  },
  {
    id: "cover-letter",
    title: "AI Cover Letter Generator",
    description: "Generate personalized cover letters that grab attention in less than 30 seconds.",
    icon: <MessageSquare className="w-6 h-6 text-indigo-600" />,
    cta: "Generate Now"
  },
  {
    id: "interview",
    title: "Interview Prep Tool",
    description: "Practice with AI-generated questions specific to remote roles in tech and marketing.",
    icon: <Briefcase className="w-6 h-6 text-emerald-600" />,
    cta: "Start Practice"
  }
];

// Testimonials Data
const TESTIMONIALS = [
  {
    name: "Sarah Jenkins",
    location: "Austin, Texas",
    text: "I was struggling for months. Used the AI Resume Builder and got 3 interviews in my first week! Highly recommend for US remote seekers.",
    rating: 5
  },
  {
    name: "David Miller",
    location: "London, UK",
    text: "The job board list is a goldmine. Found my current role at a tech startup within 10 days. The best free toolkit out there.",
    rating: 5
  },
  {
    name: "Emily Chen",
    location: "Toronto, Canada",
    text: "The Interview Prep tool helped me nail my final round. It's so specific to remote work challenges. Thank you!",
    rating: 5
  }
];

// FAQ Data
const FAQS = [
  {
    question: "Are these tools really free to use?",
    answer: "Yes! Our mission is to help job seekers in the USA, UK, and Canada land remote roles without financial barriers. All tools in the toolkit are currently free for 2026."
  },
  {
    question: "How do I get hired in just 7 days?",
    answer: "By using our AI-optimized tools, you significantly increase your application-to-interview ratio. Our users typically see a 300% increase in responses within the first week."
  },
  {
    question: "Is this toolkit updated for 2026 remote job trends?",
    answer: "Absolutely. We update our job boards and AI models weekly to reflect the latest hiring trends in the remote work landscape."
  },
  {
    question: "Do these tools work for entry-level remote jobs?",
    answer: "Yes, we have specific templates and job boards dedicated to entry-level and junior remote positions across multiple industries."
  }
];

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [isStickyVisible, setIsStickyVisible] = useState(false);

  useEffect(() => {
    document.title = SEO.title;
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute('content', SEO.description);

    const handleScroll = () => {
      setIsStickyVisible(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleCTAClick = (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    window.location.href = "https://bendspecimen.com/r5wkaisbmd?key=09dc5a976b335518ec146adb97b41b2b";
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 selection:bg-blue-100 selection:text-blue-900 overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 z-50 w-full border-b border-slate-100 bg-white/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white shrink-0">
              <Briefcase className="h-5 w-5" />
            </div>
            <span className="text-lg sm:text-xl font-bold tracking-tight text-slate-900 truncate">RemoteToolkit</span>
          </div>
          
          <div className="hidden md:flex md:items-center md:gap-6 lg:gap-8">
            <a href="#problem" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">The Problem</a>
            <a href="#solution" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Tools</a>
            <a href="#social-proof" className="text-sm font-medium text-slate-600 hover:text-blue-600 transition-colors">Success Stories</a>
            <button 
              onClick={() => handleCTAClick()}
              className="rounded-full bg-blue-600 px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-200 hover:bg-blue-700 hover:shadow-blue-300 transition-all active:scale-95 cursor-pointer"
            >
              Start Free
            </button>
          </div>

          <button 
            className="md:hidden p-2 -mr-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="absolute w-full border-b border-slate-100 bg-white overflow-hidden md:hidden"
            >
              <div className="flex flex-col gap-4 p-4">
                <a href="#problem" onClick={() => setIsMenuOpen(false)} className="text-base font-medium text-slate-600 px-2 py-1">The Problem</a>
                <a href="#solution" onClick={() => setIsMenuOpen(false)} className="text-base font-medium text-slate-600 px-2 py-1">Tools</a>
                <a href="#social-proof" onClick={() => setIsMenuOpen(false)} className="text-base font-medium text-slate-600 px-2 py-1">Success Stories</a>
                <button 
                  onClick={() => { setIsMenuOpen(false); handleCTAClick(); }}
                  className="w-full rounded-xl bg-blue-600 py-3.5 text-center font-bold text-white shadow-lg shadow-blue-200 active:scale-[0.98] transition-transform"
                >
                  Get Started Now
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-28 pb-16 sm:pt-32 sm:pb-20 lg:pt-48 lg:pb-32">
        {/* Background Gradients */}
        <div className="absolute top-0 -z-10 h-full w-full pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] h-[300px] w-[300px] sm:h-[500px] sm:w-[500px] rounded-full bg-blue-50/50 blur-[80px] sm:blur-[120px]"></div>
          <div className="absolute bottom-[-10%] right-[-10%] h-[300px] w-[300px] sm:h-[500px] sm:w-[500px] rounded-full bg-purple-50/50 blur-[80px] sm:blur-[120px]"></div>
        </div>

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50/50 px-3 py-1 sm:px-4 sm:py-1.5 text-xs sm:text-sm font-medium text-blue-700"
            >
              <ShieldCheck className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
              <span>Trusted by 50,000+ Job Seekers in USA, UK & Canada</span>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="mt-6 sm:mt-8 text-3xl font-extrabold tracking-tight text-slate-900 sm:text-6xl lg:text-7xl leading-[1.1]"
            >
              Land a Remote Job in <span className="text-blue-600">7 Days</span> <br className="hidden sm:block" />
              Using These Free Tools
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="mx-auto mt-4 sm:mt-6 max-w-2xl text-base text-slate-600 sm:text-xl px-2"
            >
              The ultimate 2026 remote job finder toolkit. Stop sending resumes into the void. Use AI to get noticed by top companies hiring remotely today.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="mt-8 sm:mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row"
            >
              <button 
                onClick={() => handleCTAClick()}
                className="group relative flex w-full items-center justify-center gap-2 overflow-hidden rounded-full bg-slate-900 px-8 py-4 text-base sm:text-lg font-bold text-white shadow-2xl transition-all hover:bg-slate-800 sm:w-auto active:scale-95 cursor-pointer"
              >
                <span>Start Now — It's Free</span>
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
              </button>
              <div className="flex items-center gap-3 sm:gap-4 text-xs sm:text-sm font-medium text-slate-500">
                <div className="flex -space-x-2">
                  {[1,2,3,4].map(i => (
                    <img 
                      key={i}
                      src={`https://picsum.photos/seed/user${i}/40/40`} 
                      className="h-7 w-7 sm:h-8 sm:w-8 rounded-full border-2 border-white shrink-0"
                      alt="User"
                      referrerPolicy="no-referrer"
                    />
                  ))}
                </div>
                <span>Join 5k+ this week</span>
              </div>
            </motion.div>

            {/* Trust Badges */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="mt-12 sm:mt-16 flex flex-wrap justify-center gap-4 sm:gap-6 opacity-60 grayscale hover:grayscale-0 transition-all duration-500"
            >
              {TRUST_BADGES.map((badge, idx) => (
                <div key={idx} className="flex items-center gap-1.5 sm:gap-2 text-xs sm:text-sm font-semibold text-slate-600">
                  {badge.icon}
                  <span>{badge.name}</span>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section id="problem" className="bg-slate-50 py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
            <div className="order-2 lg:order-1">
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl leading-tight">
                Why 95% of Job Seekers Fail to Get Remote Interviews
              </h2>
              <p className="mt-4 text-base sm:text-lg text-slate-600">
                Applying for remote jobs in 2026 is harder than ever. Competition is global, and companies use strict AI filters to reject 90% of applicants before a human even sees them.
              </p>
              
              <ul className="mt-6 sm:mt-8 space-y-3 sm:space-y-4">
                {[
                  "No replies after hundreds of applications",
                  "Resume not optimized for ATS (Applicant Tracking Systems)",
                  "Generic cover letters that recruiters ignore",
                  "Lack of experience in remote-specific tools"
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div className="mt-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-100 text-red-600 shrink-0">
                      <X className="h-3 w-3" />
                    </div>
                    <span className="text-sm sm:text-base text-slate-700 font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="relative order-1 lg:order-2">
              <div className="aspect-video overflow-hidden rounded-2xl bg-white p-5 sm:p-8 shadow-xl shadow-slate-200 border border-slate-100">
                <div className="flex h-full flex-col justify-center gap-4 sm:gap-6">
                  <div className="h-3 sm:h-4 w-3/4 rounded bg-slate-100"></div>
                  <div className="h-3 sm:h-4 w-1/2 rounded bg-slate-100"></div>
                  <div className="h-3 sm:h-4 w-5/6 rounded bg-slate-100"></div>
                  <div className="mt-2 sm:mt-4 flex items-center gap-3 sm:gap-4">
                    <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-red-50 text-red-600 flex items-center justify-center shrink-0">
                      <X className="h-5 w-5 sm:h-6 sm:w-6" />
                    </div>
                    <div className="text-xs sm:text-sm font-bold text-red-600 uppercase tracking-wider">Application Rejected</div>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-400 italic">"Unfortunately, we've decided to move forward with other candidates..."</p>
                </div>
              </div>
              {/* Floating Badge */}
              <div className="absolute -bottom-4 -right-2 sm:-bottom-6 sm:-right-6 rounded-xl bg-white p-3 sm:p-4 shadow-lg border border-slate-100">
                <div className="text-[10px] sm:text-xs font-bold text-slate-400 uppercase">Average Competition</div>
                <div className="text-lg sm:text-2xl font-bold text-slate-900">1,200+ Applicants</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section id="solution" className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
              Everything You Need to Get Hired Fast
            </h2>
            <p className="mt-3 sm:mt-4 text-base sm:text-lg text-slate-600">
              Our toolkit bypasses the filters and puts you directly in front of hiring managers.
            </p>
          </div>

          <div className="mt-12 sm:mt-16 grid gap-6 sm:gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {TOOLS.map((tool) => (
              <motion.div 
                key={tool.id}
                whileHover={{ y: -5 }}
                className="group flex flex-col rounded-2xl border border-slate-100 bg-white p-6 sm:p-8 shadow-sm transition-all hover:shadow-md"
              >
                <div className="mb-5 sm:mb-6 flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-xl bg-slate-50 group-hover:scale-110 transition-transform shrink-0">
                  {tool.icon}
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-slate-900">{tool.title}</h3>
                <p className="mt-2 sm:mt-3 flex-grow text-sm leading-relaxed text-slate-600">
                  {tool.description}
                </p>
                <button 
                  onClick={() => handleCTAClick()}
                  className="mt-6 sm:mt-8 flex items-center justify-center gap-2 rounded-lg bg-blue-50 py-3 text-sm font-bold text-blue-600 hover:bg-blue-600 hover:text-white transition-all active:scale-95 cursor-pointer"
                >
                  <span>{tool.cta}</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Proof Section */}
      <section id="social-proof" className="bg-slate-900 py-16 sm:py-24 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight sm:text-4xl">
              Success Stories from the Community
            </h2>
            <p className="mt-3 sm:mt-4 text-base sm:text-lg text-slate-400">
              Join thousands of remote workers who started their journey here.
            </p>
          </div>

          <div className="mt-12 sm:mt-16 grid gap-6 sm:gap-8 lg:grid-cols-3">
            {TESTIMONIALS.map((t, idx) => (
              <div key={idx} className="rounded-2xl bg-white/5 p-6 sm:p-8 backdrop-blur-sm border border-white/10">
                <div className="flex gap-1">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} className="h-3.5 w-3.5 sm:h-4 sm:w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="mt-4 sm:mt-6 text-base sm:text-lg italic text-slate-300 leading-relaxed">"{t.text}"</p>
                <div className="mt-6 sm:mt-8 flex items-center gap-3 sm:gap-4">
                  <img 
                    src={`https://picsum.photos/seed/${t.name}/60/60`} 
                    className="h-10 w-10 sm:h-12 sm:w-12 rounded-full border-2 border-blue-500/30 shrink-0"
                    alt={t.name}
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <div className="text-sm sm:text-base font-bold">{t.name}</div>
                    <div className="text-xs sm:text-sm text-slate-400">{t.location}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 sm:mt-20 flex flex-wrap justify-center gap-8 sm:gap-12 opacity-50 grayscale invert">
            {/* Mock Company Logos */}
            <div className="text-xl sm:text-2xl font-black tracking-tighter">STRIPE</div>
            <div className="text-xl sm:text-2xl font-black tracking-tighter">NOTION</div>
            <div className="text-xl sm:text-2xl font-black tracking-tighter">AIRBNB</div>
            <div className="text-xl sm:text-2xl font-black tracking-tighter">SHOPIFY</div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-blue-600 px-6 py-12 sm:px-8 sm:py-16 text-center text-white shadow-2xl shadow-blue-200">
            {/* Decorative circles */}
            <div className="absolute -top-24 -left-24 h-48 w-48 sm:h-64 sm:w-64 rounded-full bg-blue-500/50 blur-3xl pointer-events-none"></div>
            <div className="absolute -bottom-24 -right-24 h-48 w-48 sm:h-64 sm:w-64 rounded-full bg-blue-400/50 blur-3xl pointer-events-none"></div>
            
            <div className="relative z-10">
              <h2 className="text-2xl font-bold sm:text-5xl leading-tight">
                Limited Free Access Available Today
              </h2>
              <p className="mx-auto mt-4 sm:mt-6 max-w-xl text-base sm:text-lg text-blue-100">
                Due to high demand, we may soon move to a paid model. Secure your lifetime free access to the toolkit by starting today.
              </p>
              <div className="mt-8 sm:mt-10 flex flex-col items-center gap-4 sm:gap-6">
                <button 
                  onClick={() => handleCTAClick()}
                  className="group flex w-full items-center justify-center gap-2 sm:gap-3 rounded-full bg-white px-8 py-4 sm:px-10 sm:py-5 text-lg sm:text-xl font-bold text-blue-600 shadow-xl transition-all hover:bg-blue-50 sm:w-auto active:scale-95 cursor-pointer"
                >
                  <span>Get My Free Toolkit Now</span>
                  <ArrowRight className="h-5 w-5 sm:h-6 sm:w-6 transition-transform group-hover:translate-x-1" />
                </button>
                <div className="flex items-center gap-2 text-xs sm:text-sm font-medium text-blue-100">
                  <Clock className="h-3.5 w-3.5 sm:h-4 sm:w-4" />
                  <span>Offer expires in: 14:59</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-slate-50 py-16 sm:py-24">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
              Frequently Asked Questions
            </h2>
            <p className="mt-3 sm:mt-4 text-base sm:text-lg text-slate-600">
              Everything you need to know about the Remote Job Finder Toolkit.
            </p>
          </div>

          <div className="mt-10 sm:mt-12 space-y-3 sm:space-y-4">
            {FAQS.map((faq, idx) => (
              <div 
                key={idx}
                className="overflow-hidden rounded-xl border border-slate-200 bg-white"
              >
                <button 
                  onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                  className="flex w-full items-center justify-between p-5 sm:p-6 text-left"
                >
                  <span className="text-base sm:text-lg font-bold text-slate-900 pr-4">{faq.question}</span>
                  <ChevronDown className={`h-5 w-5 text-slate-400 transition-transform shrink-0 ${activeFaq === idx ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {activeFaq === idx && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="border-t border-slate-100"
                    >
                      <div className="p-5 sm:p-6 text-sm sm:text-base text-slate-600 leading-relaxed">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-100 bg-white py-10 sm:py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 md:grid-cols-4">
            <div className="col-span-2">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 text-white shrink-0">
                  <Briefcase className="h-5 w-5" />
                </div>
                <span className="text-lg sm:text-xl font-bold tracking-tight text-slate-900">RemoteToolkit</span>
              </div>
              <p className="mt-4 max-w-xs text-sm text-slate-500 leading-relaxed">
                Helping job seekers in USA, UK, and Canada land their dream remote roles with AI-powered tools and curated job boards.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-8 col-span-2 md:col-span-2">
              <div>
                <h4 className="text-sm sm:text-base font-bold text-slate-900">Legal</h4>
                <ul className="mt-3 sm:mt-4 space-y-2 text-xs sm:text-sm text-slate-500">
                  <li><a href="#" className="hover:text-blue-600 transition-colors">Privacy Policy</a></li>
                  <li><a href="#" className="hover:text-blue-600 transition-colors">Terms of Service</a></li>
                  <li><a href="#" className="hover:text-blue-600 transition-colors">Disclaimer</a></li>
                </ul>
              </div>
              
              <div>
                <h4 className="text-sm sm:text-base font-bold text-slate-900">Support</h4>
                <ul className="mt-3 sm:mt-4 space-y-2 text-xs sm:text-sm text-slate-500">
                  <li><a href="#" className="hover:text-blue-600 transition-colors">Contact Us</a></li>
                  <li><a href="#" className="hover:text-blue-600 transition-colors">Help Center</a></li>
                  <li><a href="#" className="hover:text-blue-600 transition-colors">Feedback</a></li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="mt-10 sm:mt-12 border-t border-slate-100 pt-8 text-center text-[10px] sm:text-xs text-slate-400">
            <p>© 2026 Remote Job Finder Toolkit. All rights reserved. Designed for Tier 1 Job Seekers.</p>
            <p className="mt-2">Disclaimer: We are not affiliated with any specific job board. Results may vary based on individual effort and profile quality.</p>
          </div>
        </div>
      </footer>

      {/* Sticky Mobile CTA */}
      <AnimatePresence>
        {isStickyVisible && (
          <motion.div 
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            className="fixed bottom-6 left-0 z-50 w-full px-4 md:hidden"
          >
            <button 
              onClick={() => handleCTAClick()}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-blue-600 py-4 font-bold text-white shadow-2xl shadow-blue-400 active:scale-95 cursor-pointer"
            >
              <span>Get Free Access Now</span>
              <ArrowRight className="h-5 w-5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
